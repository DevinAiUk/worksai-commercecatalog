=== worksai-commercecatalog ===
Requires PHP: 8.1
License: MIT

Upload `worksai-commercecatalog.zip` in WordPress Admin -> Plugins -> Add New -> Upload Plugin, or require `worksai-commercecatalog-bridge.php` in PHP 8.2+.
